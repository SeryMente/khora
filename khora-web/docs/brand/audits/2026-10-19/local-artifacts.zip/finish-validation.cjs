﻿const fs=require('fs'),path=require('path'),cp=require('child_process');
const w=__dirname,c=JSON.parse(fs.readFileSync(path.join(w,'context.json'),'utf8').replace(/^\uFEFF/,''));
const web=path.join(c.root,'khora-web');
(async()=>{
 let done=false;for(let n=0;n<240;n++){if(fs.readFileSync(path.join(w,'browser-final.log'),'utf8').includes('failed\n')&&fs.statSync(path.join(w,'playwright-results.json')).mtimeMs>Date.now()-20000){done=true;break;}await new Promise(r=>setTimeout(r,2000));}
 if(!done)throw Error('SAFE_STOP full run did not finish in bounded wait');
 for(const [a,b] of [['browser-final.log','browser-with-fixture-errors.log'],['playwright-results.json','browser-with-fixture-errors.json']])fs.copyFileSync(path.join(w,a),path.join(w,b));
 cp.execFileSync('powershell.exe',['-NoProfile','-Command',`Compress-Archive -Path '${path.join(w,'test-results')}' -DestinationPath '${path.join(w,'fixture-errors-artifacts.zip')}'`]);
 let p=path.join(web,'e2e/shell-v2.spec.ts'),s=fs.readFileSync(p,'utf8');s=s.replace(/path: '\/grafo', expectedTitle: '[^']+'/,"path: '/grafo', expectedTitle: 'Grafo'");fs.writeFileSync(p,s);
 p=path.join(web,'e2e/ui-quality.spec.ts');s=fs.readFileSync(p,'utf8');const start=s.indexOf('test("el grafo mantiene'),end=s.indexOf('await page.goto("/grafo"',start);if(start<0||end<0)throw Error('SAFE_STOP fixture match');let part=s.slice(start,end);part=part.replace('nodes: [','source_count: 1, pending: 0, revision: "ui-fixture", automatic: { nodes: [').replace('edges: [],','edges: [], communities: 1 }, curated: { nodes: [], edges: [], communities: 0 }, proposals: [], judgments: [],');s=s.slice(0,start)+part+s.slice(end);fs.writeFileSync(p,s);
 let runner=fs.readFileSync(path.join(w,'validate-fix.cjs'),'utf8');runner=runner.replace("env.PATH=path.dirname(c.gh)+';'+previousPath;","env.PATH=path.join(w,'python')+';'+path.dirname(c.gh)+';'+previousPath;");runner=runner.replace("const build=await run('build-final','npm run build');","const build=await run('typecheck-final','npm run typecheck');");fs.writeFileSync(path.join(w,'validate-fixtures.cjs'),runner);
 console.log('Fixtures aligned without product changes; launch final complete browser run');cp.execFileSync(process.execPath,[path.join(w,'validate-fixtures.cjs')],{stdio:'inherit',timeout:1200000});
 console.log('FINAL_VALIDATION_COMPLETE');
})().catch(e=>{console.error(e.message);process.exitCode=1});
